﻿/*using System;

namespace _1
{
	class MainClass //主类：包含Main函数的类叫做主类
	{
		public static void Main(string[] args)
		{
			Person p1 = new Person();//创建了一个具体的对象
			Person p2 = new Person();
			//p1和p2都具备Person类中声明的所有的属性和行为
			//p1.name私有成员不可以在类外直接访问，目的是为了实现封装性
			//私有成员不能直接访问，可以通过公有的方法或创建属性去访问
			p1.setName("zhangsan");//通过setName给p1设置name
			p2.setName("lisi");//通过setName给p2设置name
			p1.setAge(20);
			p2.setAge(21);
			p1.setId(201801);
			p2.setId(201802);

			Console.WriteLine(p1.getName());
			Console.WriteLine(p2.getName());

			p1.print();
			p2.print();
		}
	}
	//声明类用class关键字
	//类是对一组对象进行的抽象的统一的描述，在类中描述了所有该类对象的属性(字段)和行为(方法)
	class Person
	{
		private string name;
		private int age;
		private int id;
		//public声明的成员表示公有的成员，可以在类外直接访问的成员
		//private声明的成员表示私有的成员，在类外不可以直接访问的成员

		//创建公有方法设置对象的姓名、年龄、id
		//方法功能：传入字符串，修改对象的name
		//方法名字：setName
		//方法参数列表：(string _name)
		//方法返回值类型：void
		public void setName(string _name)
		{
			name = _name;
		}
		public void setAge(int _age)
		{
			age = _age;
		}
		public void setId(int _id)
		{
			id = _id;
		}

		//方法功能：返回该对象的名字
		//方法名字：getName
		//方法参数列表：()
		//方法返回值类型：string
		public string getName()
		{
			return name;
		}

		public void print()
		{
			Console.WriteLine("name:{0},age:{1},id:{2}", name, age, id);
		}
	}
}
*/
/*using System;
namespace aa
{
	class MainClass
	{
		public static void Main()
		{
			Person p = new Person();
			p.Name = "zhangsan";
			//将p.Name放在等号左边调用Name属性的set方法，等号右边的值就是隐藏的value参数
			Console.WriteLine(p.Name);
			//将p.Name放在等号右边或者直接放在Console.WriteLine中是调用属性的get方法
		}
	}

	class Person
	{
		private string name;
		private int age;
		private int id;

		//对私有字段的访问
		//属性的作用：访问私有字段
		//属性的本质：通过属性自动生成字段的set方法和get方法
		public string Name //Name是属性的名字，string是属性的类型(访问的字段的类型)
		{
			get { return name; }//get方法要返回name字段
			set { name = value; }//value是隐藏的参数，将value的值赋值给name
		}
	}
}*/
/*using System;
namespace aa
{
	class MainClass
	{
		public static void Main()
		{
			Person p = new Person();
			p.Name = "zhangsan";
			p.Age = 20;
			p.Id = 201801;

			Date d = new Date();
			d.Year = 2010;
			d.Month = 5;
			d.Day = 1;
			p.Birthday = d;

			p.print();
		}
	}

	class Date
	{
		private int year;
		private int month;
		private int day;

		public int Year
		{
			get { return year; }
			set { year = value; }
		}
		public int Month
		{
			get { return month; }
			set { month = value; }
		}
		public int Day
		{
			get { return day; }
			set { day = value; }
		}

		public void print()
		{
			Console.WriteLine("{0}年{1}月{2}日", year, month, day);
		}
	}
	class Person
	{
		private string name;
		private int age;
		private int id;
		private Date birthday;//用Date日期对象表示生日，跟普通字段一样

		public string Name
		{
			get { return name; }
			set { name = value; }
		}
		public int Age
		{
			get { return age; }
			set { age = value; }
		}
		public int Id
		{
			get { return id; }
			set { id = value; }
		}
		public Date Birthday
		{
			get { return birthday; }
			set { birthday = value; }
		}
		public void print()
		{
			Console.Write("{0},{1},{2},", name, age, id);
			birthday.print();
		}
	}
}*/
/*using System;
namespace aa
{
	class MainClass
	{
		public static void Main()
		{
			Point p = new Point();
			//p.X = 10;
			//p.Y = 20;
			Console.WriteLine("{0},{1}", p.X, p.Y);
		}
	}

	class Point
	{
		private int x;
		private int y;

		//私有属性，在set或get方法前加private
		//私有set或不写set是只读属性，只能在类外调用get方法
		//私有get或不写get是只写属性，只能在类外调用set方法
		public int X
		{
			get { return x; }
		}
		public int Y
		{
			get { return y; }
			private set { y = value; }
		}
	}
}*/
/*using System;
namespace aa
{
	class MainClass
	{
		public static void Main()
		{
			Person p = new Person();
			p.Age = -20;
		}
	}

	class Person
	{
		private string name;
		private int age;
		private int id;

		public int Age
		{
			get { return age; }
			set
			{
				//age = value;
				//if (age <= 0)
				//{
				//	Console.WriteLine("年龄设置错误");
				//	age = 1;
				//}
				age = value <= 0 ? 1 : value;
			}
		}
	}
}*/
/*using System;
namespace aa
{
	class MainClass
	{
		public static void Main()
		{
			Circle c1 = new Circle();
			Circle c2 = new Circle();

			c1.X = 2;
			c1.Y = 4;
			c1.Radius = 5;

			c2.X = 5;
			c2.Y = 8;
			c2.Radius = 7;

			//求圆的面积
			Console.WriteLine(c1.area());
			Console.WriteLine(c2.area());
			//求两个圆的圆心距
			Console.WriteLine(c1.distance(c2));
			//c2.distance(c1);
		}
	}

	class Circle
	{
		private int x;
		private int y;
		private int radius;

		public int X
		{
			get { return x; }
			set { x = value; }
		}
		public int Y
		{
			get { return y; }
			set { y = value; }
		}
		public int Radius
		{
			get { return radius; }
			set { radius = value; }
		}

		public double area()
		{
			return Math.PI * radius * radius;
		}
		public double distance(Circle anotherCircle)
		{
			int tx = x - anotherCircle.x;
			int ty = y - anotherCircle.y;
			return Math.Sqrt(tx * tx + ty * ty);
		}
	}
}*/
/*using System;
namespace aa
{
	class MainClass
	{
		public static void Main()
		{
			Student p1 = new Student();
			Student p2 = new Student();

			Student.teacher = "a";
			Student.roomNum = 506;
			//静态成员是属于整个类的，要通过类名.访问
		}
	}

	class Student
	{
		private string name;//非静态成员属于某个具体对象 
		public static string teacher;//静态成员属于整个类
		public static int roomNum;

		public string Name
		{
			get { return name; }
			set { name = value; }
		}

		public static string Teacher
		{
			get { return teacher; }
			set { teacher = value; }
		}

		public static void printTeacher()
		{
			Console.WriteLine(teacher);
		}
	}
}*/
using System;
namespace aa
{
	class MainClass
	{
		public static void Main()
		{
			Student s1 = new Student();
			Student s2 = new Student();

			//Student.teacher = "a";
			//Student.Name = "zhangsan"; error
			Student.teacher = "a";
			s1.fun2();
			s2.fun2();
			Student.teacher = "b";
			s1.fun2();
			s2.fun2();
			//s1对象和s2对象访问的是同一个静态字段
		}
	}
	//static成员的访问：
	//1.类可以访问静态成员
	//2.类中的静态方法可以静态成员
	//3.类中的非静态方法可以访问静态成员

	//非static成员的访问：
	//1.类不可以直接访问非静态成员
	//2.类中的静态方法不可以直接访问非静态成员
	//3.只有具体对象和非静态方法可以访问非静态成员

	//静态的只能访问静态的 非静态可以访问静态的也可以访问非静态的
	class Student
	{
		private string name;
		private int age;
		public static string teacher;

		public string Name
		{
			get { return name; }
			set { name = value; }
		}

		public static void fun()
		{
			Console.WriteLine(teacher);
			//Console.WriteLine(name);error
		}
		public void fun2()
		{
			Console.WriteLine(teacher);
		}
	}
}